# Simulation de lancer de d�s en Python.
